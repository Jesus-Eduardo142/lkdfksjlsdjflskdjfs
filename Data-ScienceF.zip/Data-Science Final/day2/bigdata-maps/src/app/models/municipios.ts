export class Municipios {
    idmunicipio: string;
    municipio: string;
}