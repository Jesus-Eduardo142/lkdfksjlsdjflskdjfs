export class Denues {
    nombre: string;
    tipo: string;
    descripcion: string;
    calle: string;
    numero: string;
    colonia: string;
    cp: string;
    idestado: string;
    estado: string;
    idmunicipio: string;
    municipio: string;
    lat: string;
    lng: string;
}
  