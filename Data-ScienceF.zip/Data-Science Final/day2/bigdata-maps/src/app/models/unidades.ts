export class Unidades {
    tipo: string;
    descripcion: string;
}