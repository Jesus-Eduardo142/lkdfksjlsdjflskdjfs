export class Estados {
    idestado: string;
    estado: string;

}
  